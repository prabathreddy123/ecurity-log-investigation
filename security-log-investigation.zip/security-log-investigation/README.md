# Security Log Investigation

Investigation of a synthetic authentication log (12 events, 2026-08-01 UTC): normalize the data, define detection rules, build a timeline, and separate evidence from assumptions.

> Educational project using EdVyro's supplied synthetic data. All IPs are documentation-range addresses; no real people or systems are involved.

## Deliverables
| File | What it is |
|---|---|
| `incident_report.pdf` | 2-page incident report: summary, findings, timeline, evidence vs assumptions, response actions |
| `investigation_workbook.xlsx` | Cleaned log, detection rules (formula-driven), timeline, evidence vs assumptions, summary |
| `detect.py` | Repeatable script that normalizes the log and applies the three rules |
| `detect_output.txt` | Output of `python detect.py` |
| `data/authentication-log-sample.csv` | Original log, unchanged |
| `data/normalized_log.csv` | Normalized log with event IDs E01-E12 |

## Findings in brief
1. **Brute force:** stu-117, 3 failed logins from 198.51.100.27 in 34 s, then the account was locked. No breach shown.
2. **Password spraying:** 203.0.113.42 failed against 4 accounts (stu-209, 311, 415, 502) in 12 s. All failed.
3. **Needs verification:** stu-311, one of the sprayed accounts, logged in from a new IP and device (192.0.2.99, ios) 2 h 26 min later. Not proven malicious.

## Detection rules
| Rule | Logic |
|---|---|
| 1 Brute force | 3+ failed logins, one account, one IP, within 5 min |
| 2 Password spraying | Failures from one IP against 3+ accounts within 2 min |
| 3 Unusual access | Successful login from an IP not seen before for that account, after earlier failures |

## Run it
```bash
python detect.py
```
Python 3.8+, standard library only.

Author: [Your Name]
