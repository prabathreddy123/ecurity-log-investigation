"""Security Log Investigation: normalize the log and apply three detection rules.
Standard library only. Usage: python detect.py
"""
import csv
from collections import defaultdict
from datetime import datetime, timedelta

SRC = "data/authentication-log-sample.csv"
OUT = "data/normalized_log.csv"

BRUTE_FORCE_FAILS = 3                      # failures for ONE account from ONE ip ...
BRUTE_FORCE_WINDOW = timedelta(minutes=5)  # ... within this window
SPRAY_ACCOUNTS = 3                         # distinct accounts failing from ONE ip ...
SPRAY_WINDOW = timedelta(minutes=2)        # ... within this window


def load():
    rows = []
    with open(SRC, newline="") as f:
        for i, r in enumerate(csv.DictReader(f), start=1):
            rows.append({
                "event_id": f"E{i:02d}",
                "timestamp_utc": datetime.strptime(r["timestamp"], "%Y-%m-%dT%H:%M:%SZ"),
                "user_id": r["user_id"].strip().lower(),
                "source_ip": r["source_ip"].strip(),
                "event": r["event"].strip().lower(),
                "result": r["result"].strip().lower(),
                "device": r["device"].strip().lower(),
            })
    rows.sort(key=lambda x: x["timestamp_utc"])
    return rows


def write_normalized(rows):
    with open(OUT, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["event_id", "timestamp_utc", "user_id", "source_ip", "event", "result", "device"])
        for r in rows:
            w.writerow([r["event_id"], r["timestamp_utc"].strftime("%Y-%m-%d %H:%M:%S"), r["user_id"],
                        r["source_ip"], r["event"], r["result"], r["device"]])


def brute_force(rows):
    groups = defaultdict(list)
    for r in rows:
        if r["event"] == "password_login" and r["result"] == "failure":
            groups[(r["user_id"], r["source_ip"])].append(r)
    hits = []
    for (user, ip), evs in groups.items():
        for i in range(len(evs)):
            window = [e for e in evs[i:] if e["timestamp_utc"] - evs[i]["timestamp_utc"] <= BRUTE_FORCE_WINDOW]
            if len(window) >= BRUTE_FORCE_FAILS:
                hits.append((user, ip, window))
                break
    return hits


def spraying(rows):
    groups = defaultdict(list)
    for r in rows:
        if r["event"] == "password_login" and r["result"] == "failure":
            groups[r["source_ip"]].append(r)
    hits = []
    for ip, evs in groups.items():
        for i in range(len(evs)):
            window = [e for e in evs[i:] if e["timestamp_utc"] - evs[i]["timestamp_utc"] <= SPRAY_WINDOW]
            if len({e["user_id"] for e in window}) >= SPRAY_ACCOUNTS:
                hits.append((ip, window))
                break
    return hits


def unusual_access(rows):
    hits = []
    for i, r in enumerate(rows):
        if r["event"] == "password_login" and r["result"] == "success":
            before = [p for p in rows[:i] if p["user_id"] == r["user_id"]]
            prior_fail = [p for p in before if p["result"] == "failure"]
            seen_ip = any(p["source_ip"] == r["source_ip"] for p in before)
            if prior_fail and not seen_ip:
                hits.append((r, prior_fail))
    return hits


def fmt(e):
    return (f'{e["event_id"]} {e["timestamp_utc"]:%H:%M:%S} {e["user_id"]} {e["source_ip"]} '
            f'{e["event"]}/{e["result"]} ({e["device"]})')


if __name__ == "__main__":
    rows = load()
    write_normalized(rows)
    print(f"Loaded {len(rows)} events, {rows[0]['timestamp_utc']:%Y-%m-%d %H:%M:%S} to "
          f"{rows[-1]['timestamp_utc']:%H:%M:%S} UTC. Wrote {OUT}\n")

    print("RULE 1  Brute force (>=3 failures, 1 account, 1 IP, within 5 min)")
    for user, ip, evs in brute_force(rows):
        print(f"  MATCH {user} from {ip}: {len(evs)} failures")
        for e in evs:
            print("     ", fmt(e))

    print("\nRULE 2  Password spraying (>=3 distinct accounts failing from 1 IP within 2 min)")
    for ip, evs in spraying(rows):
        span = (evs[-1]["timestamp_utc"] - evs[0]["timestamp_utc"]).seconds
        print(f"  MATCH {ip}: {len({e['user_id'] for e in evs})} accounts in {span}s")
        for e in evs:
            print("     ", fmt(e))

    print("\nRULE 3  Unusual access (success from an IP never seen for that account, after earlier failures)")
    for r, pf in unusual_access(rows):
        print(f"  REVIEW {fmt(r)}")
        for e in pf:
            print("     prior failure:", fmt(e))

    print("\nControl events (informational)")
    for r in rows:
        if r["event"] in ("account_lock", "rate_limit"):
            print("  ", fmt(r))
